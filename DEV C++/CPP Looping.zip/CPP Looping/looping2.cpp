#include <iostream>

using namespace std;

int main() {
    int i = 0;
    while(i != 99) {

        cout << "Masukkan Sebuah Bilangan : ";
        cin >> i;
        cout << "Bilangan Anda Adalah = " << i << endl;
    }

    cout << "\n";

    return 0;
}