#include <iostream>

using namespace std;

int main()
{
    int x;
    x = 1;//awal variabel
    while(x <= 10)//batas akhir 
    { 
        cout << "Bahasa C++" << endl;
        x++;//variabel x ditambah 1
    }
    return 0;
}
