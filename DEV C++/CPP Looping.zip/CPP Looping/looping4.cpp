#include <iostream>

using namespace std;
int main() {
    int x;
for(x = 1; x <= 10; x++) {
    cout << "BAHASA C++" << endl;
}
return 0;
}