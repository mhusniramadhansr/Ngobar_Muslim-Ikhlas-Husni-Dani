#include <iostream>

using namespace std;

int main() {
    int x;
    x = 1;
    do
    {
        cout << "BAHASA C++" << endl;
        x++;
    } while (x <= 10);

    return 0;
}